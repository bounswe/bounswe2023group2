package com.example.disasterresponseplatform.ui.activity.emergency

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R


class AddEmergencyFragment : Fragment(R.layout.fragment_add_emergency)