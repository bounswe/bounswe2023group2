package com.example.disasterresponseplatform.data.enums

enum class PredefinedTypes(val type: Int) {
    Clothes(1),
    Human(2),
    Food(3),
    Collapse(4),
    Debris(5),
}