package com.example.disasterresponseplatform.ui.activity.action

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R


class AddActionFragment : Fragment(R.layout.fragment_add_action)