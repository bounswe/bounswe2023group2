package com.example.disasterresponseplatform.ui.profile.pastUserActions

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R

class PastUserActionsFragment : Fragment(R.layout.fragment_past_user_actions)