package com.example.disasterresponseplatform.ui.activity.need

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R


class AddNeedFragment : Fragment(R.layout.fragment_add_need)