package com.example.disasterresponseplatform.ui.map

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R


class MapFragment : Fragment(R.layout.fragment_map)