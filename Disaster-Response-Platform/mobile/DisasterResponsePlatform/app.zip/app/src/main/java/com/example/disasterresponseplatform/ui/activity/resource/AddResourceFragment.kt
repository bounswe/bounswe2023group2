package com.example.disasterresponseplatform.ui.activity.resource

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R


class AddResourceFragment : Fragment(R.layout.fragment_add_resource)