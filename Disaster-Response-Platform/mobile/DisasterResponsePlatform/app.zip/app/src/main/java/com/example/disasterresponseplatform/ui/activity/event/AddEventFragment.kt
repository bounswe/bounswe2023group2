package com.example.disasterresponseplatform.ui.activity.event

import androidx.fragment.app.Fragment
import com.example.disasterresponseplatform.R

class AddEventFragment : Fragment(R.layout.fragment_add_event)