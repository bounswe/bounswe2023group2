package com.example.disasterresponseplatform.data.enums

enum class RequestType {
    GET, POST, PUT, DELETE // Add more HTTP methods as needed
}